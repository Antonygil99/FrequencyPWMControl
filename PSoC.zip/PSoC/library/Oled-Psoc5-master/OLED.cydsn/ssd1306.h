/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


#ifndef _SSD1306_H
#define _SSD1306_H
    



    
#define BLACK 0
#define WHITE 1
#define INVERSE 2   

typedef enum{
    SCROLL_RIGHT = 0x26,
    SCROLL_LEFT = 0x2A
}SCROLL_DIR;

typedef enum{
    SCROLL_SPEED_0 = 0x03,  // slowest
    SCROLL_SPEED_1 = 0x02,
    SCROLL_SPEED_2 = 0x01,
    SCROLL_SPEED_3 = 0x06,
    SCROLL_SPEED_4 = 0x00,
    SCROLL_SPEED_5 = 0x05,
    SCROLL_SPEED_6 = 0x04,
    SCROLL_SPEED_7 = 0x07   // fastest
}SCROLL_SPEED;

typedef enum{
    SCROLL_PAGE_0 = 0,
    SCROLL_PAGE_1,
    SCROLL_PAGE_2,
    SCROLL_PAGE_3,
    SCROLL_PAGE_4,
    SCROLL_PAGE_5,
    SCROLL_PAGE_6,
    SCROLL_PAGE_7   
}SCROLL_AREA;

void display_init( int i2caddr );
void display_update(void);
void display_clear(void);
void display_stopscroll(void);
void display_scroll( SCROLL_AREA start, SCROLL_AREA end, SCROLL_DIR dir, SCROLL_SPEED speed );
void display_contrast( int contrast );
void display_invert( int invert );




void gfx_drawPixel(int x, int y, int color);
void gfx_drawLine( int x0, int y0, int x1, int y1, int color );
void gfx_setCursor( int x, int y );
void gfx_setTextSize( int size );
void gfx_setTextColor( int color );
void gfx_setTextBg( int background );
void gfx_write( int ch );
int gfx_width(void);
int gfx_height(void);
void gfx_print( const char* s );
void gfx_println( const char* s );
void gfx_drawRect( int x, int y, int w, int h, int color );
void gfx_fillRect( int x, int y, int w, int h, int color );
void gfx_drawCircle( int x0, int y0, int r, int color );
void gfx_drawTriangle( int x0, int y0,int x1, int y1, int x2, int y2, int color );
void gfx_setRotation( int x );

#endif	// _SSD1306_H



/* [] END OF FILE */
