/*******************************************************************************
* File Name: AngleSet.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_AngleSet_H) /* Pins AngleSet_H */
#define CY_PINS_AngleSet_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "AngleSet_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 AngleSet__PORT == 15 && ((AngleSet__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    AngleSet_Write(uint8 value);
void    AngleSet_SetDriveMode(uint8 mode);
uint8   AngleSet_ReadDataReg(void);
uint8   AngleSet_Read(void);
void    AngleSet_SetInterruptMode(uint16 position, uint16 mode);
uint8   AngleSet_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the AngleSet_SetDriveMode() function.
     *  @{
     */
        #define AngleSet_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define AngleSet_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define AngleSet_DM_RES_UP          PIN_DM_RES_UP
        #define AngleSet_DM_RES_DWN         PIN_DM_RES_DWN
        #define AngleSet_DM_OD_LO           PIN_DM_OD_LO
        #define AngleSet_DM_OD_HI           PIN_DM_OD_HI
        #define AngleSet_DM_STRONG          PIN_DM_STRONG
        #define AngleSet_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define AngleSet_MASK               AngleSet__MASK
#define AngleSet_SHIFT              AngleSet__SHIFT
#define AngleSet_WIDTH              1u

/* Interrupt constants */
#if defined(AngleSet__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in AngleSet_SetInterruptMode() function.
     *  @{
     */
        #define AngleSet_INTR_NONE      (uint16)(0x0000u)
        #define AngleSet_INTR_RISING    (uint16)(0x0001u)
        #define AngleSet_INTR_FALLING   (uint16)(0x0002u)
        #define AngleSet_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define AngleSet_INTR_MASK      (0x01u) 
#endif /* (AngleSet__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define AngleSet_PS                     (* (reg8 *) AngleSet__PS)
/* Data Register */
#define AngleSet_DR                     (* (reg8 *) AngleSet__DR)
/* Port Number */
#define AngleSet_PRT_NUM                (* (reg8 *) AngleSet__PRT) 
/* Connect to Analog Globals */                                                  
#define AngleSet_AG                     (* (reg8 *) AngleSet__AG)                       
/* Analog MUX bux enable */
#define AngleSet_AMUX                   (* (reg8 *) AngleSet__AMUX) 
/* Bidirectional Enable */                                                        
#define AngleSet_BIE                    (* (reg8 *) AngleSet__BIE)
/* Bit-mask for Aliased Register Access */
#define AngleSet_BIT_MASK               (* (reg8 *) AngleSet__BIT_MASK)
/* Bypass Enable */
#define AngleSet_BYP                    (* (reg8 *) AngleSet__BYP)
/* Port wide control signals */                                                   
#define AngleSet_CTL                    (* (reg8 *) AngleSet__CTL)
/* Drive Modes */
#define AngleSet_DM0                    (* (reg8 *) AngleSet__DM0) 
#define AngleSet_DM1                    (* (reg8 *) AngleSet__DM1)
#define AngleSet_DM2                    (* (reg8 *) AngleSet__DM2) 
/* Input Buffer Disable Override */
#define AngleSet_INP_DIS                (* (reg8 *) AngleSet__INP_DIS)
/* LCD Common or Segment Drive */
#define AngleSet_LCD_COM_SEG            (* (reg8 *) AngleSet__LCD_COM_SEG)
/* Enable Segment LCD */
#define AngleSet_LCD_EN                 (* (reg8 *) AngleSet__LCD_EN)
/* Slew Rate Control */
#define AngleSet_SLW                    (* (reg8 *) AngleSet__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define AngleSet_PRTDSI__CAPS_SEL       (* (reg8 *) AngleSet__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define AngleSet_PRTDSI__DBL_SYNC_IN    (* (reg8 *) AngleSet__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define AngleSet_PRTDSI__OE_SEL0        (* (reg8 *) AngleSet__PRTDSI__OE_SEL0) 
#define AngleSet_PRTDSI__OE_SEL1        (* (reg8 *) AngleSet__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define AngleSet_PRTDSI__OUT_SEL0       (* (reg8 *) AngleSet__PRTDSI__OUT_SEL0) 
#define AngleSet_PRTDSI__OUT_SEL1       (* (reg8 *) AngleSet__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define AngleSet_PRTDSI__SYNC_OUT       (* (reg8 *) AngleSet__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(AngleSet__SIO_CFG)
    #define AngleSet_SIO_HYST_EN        (* (reg8 *) AngleSet__SIO_HYST_EN)
    #define AngleSet_SIO_REG_HIFREQ     (* (reg8 *) AngleSet__SIO_REG_HIFREQ)
    #define AngleSet_SIO_CFG            (* (reg8 *) AngleSet__SIO_CFG)
    #define AngleSet_SIO_DIFF           (* (reg8 *) AngleSet__SIO_DIFF)
#endif /* (AngleSet__SIO_CFG) */

/* Interrupt Registers */
#if defined(AngleSet__INTSTAT)
    #define AngleSet_INTSTAT            (* (reg8 *) AngleSet__INTSTAT)
    #define AngleSet_SNAP               (* (reg8 *) AngleSet__SNAP)
    
	#define AngleSet_0_INTTYPE_REG 		(* (reg8 *) AngleSet__0__INTTYPE)
#endif /* (AngleSet__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_AngleSet_H */


/* [] END OF FILE */
