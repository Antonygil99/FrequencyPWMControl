/*******************************************************************************
* File Name: freqMod.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_freqMod_H) /* Pins freqMod_H */
#define CY_PINS_freqMod_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "freqMod_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 freqMod__PORT == 15 && ((freqMod__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    freqMod_Write(uint8 value);
void    freqMod_SetDriveMode(uint8 mode);
uint8   freqMod_ReadDataReg(void);
uint8   freqMod_Read(void);
void    freqMod_SetInterruptMode(uint16 position, uint16 mode);
uint8   freqMod_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the freqMod_SetDriveMode() function.
     *  @{
     */
        #define freqMod_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define freqMod_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define freqMod_DM_RES_UP          PIN_DM_RES_UP
        #define freqMod_DM_RES_DWN         PIN_DM_RES_DWN
        #define freqMod_DM_OD_LO           PIN_DM_OD_LO
        #define freqMod_DM_OD_HI           PIN_DM_OD_HI
        #define freqMod_DM_STRONG          PIN_DM_STRONG
        #define freqMod_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define freqMod_MASK               freqMod__MASK
#define freqMod_SHIFT              freqMod__SHIFT
#define freqMod_WIDTH              1u

/* Interrupt constants */
#if defined(freqMod__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in freqMod_SetInterruptMode() function.
     *  @{
     */
        #define freqMod_INTR_NONE      (uint16)(0x0000u)
        #define freqMod_INTR_RISING    (uint16)(0x0001u)
        #define freqMod_INTR_FALLING   (uint16)(0x0002u)
        #define freqMod_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define freqMod_INTR_MASK      (0x01u) 
#endif /* (freqMod__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define freqMod_PS                     (* (reg8 *) freqMod__PS)
/* Data Register */
#define freqMod_DR                     (* (reg8 *) freqMod__DR)
/* Port Number */
#define freqMod_PRT_NUM                (* (reg8 *) freqMod__PRT) 
/* Connect to Analog Globals */                                                  
#define freqMod_AG                     (* (reg8 *) freqMod__AG)                       
/* Analog MUX bux enable */
#define freqMod_AMUX                   (* (reg8 *) freqMod__AMUX) 
/* Bidirectional Enable */                                                        
#define freqMod_BIE                    (* (reg8 *) freqMod__BIE)
/* Bit-mask for Aliased Register Access */
#define freqMod_BIT_MASK               (* (reg8 *) freqMod__BIT_MASK)
/* Bypass Enable */
#define freqMod_BYP                    (* (reg8 *) freqMod__BYP)
/* Port wide control signals */                                                   
#define freqMod_CTL                    (* (reg8 *) freqMod__CTL)
/* Drive Modes */
#define freqMod_DM0                    (* (reg8 *) freqMod__DM0) 
#define freqMod_DM1                    (* (reg8 *) freqMod__DM1)
#define freqMod_DM2                    (* (reg8 *) freqMod__DM2) 
/* Input Buffer Disable Override */
#define freqMod_INP_DIS                (* (reg8 *) freqMod__INP_DIS)
/* LCD Common or Segment Drive */
#define freqMod_LCD_COM_SEG            (* (reg8 *) freqMod__LCD_COM_SEG)
/* Enable Segment LCD */
#define freqMod_LCD_EN                 (* (reg8 *) freqMod__LCD_EN)
/* Slew Rate Control */
#define freqMod_SLW                    (* (reg8 *) freqMod__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define freqMod_PRTDSI__CAPS_SEL       (* (reg8 *) freqMod__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define freqMod_PRTDSI__DBL_SYNC_IN    (* (reg8 *) freqMod__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define freqMod_PRTDSI__OE_SEL0        (* (reg8 *) freqMod__PRTDSI__OE_SEL0) 
#define freqMod_PRTDSI__OE_SEL1        (* (reg8 *) freqMod__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define freqMod_PRTDSI__OUT_SEL0       (* (reg8 *) freqMod__PRTDSI__OUT_SEL0) 
#define freqMod_PRTDSI__OUT_SEL1       (* (reg8 *) freqMod__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define freqMod_PRTDSI__SYNC_OUT       (* (reg8 *) freqMod__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(freqMod__SIO_CFG)
    #define freqMod_SIO_HYST_EN        (* (reg8 *) freqMod__SIO_HYST_EN)
    #define freqMod_SIO_REG_HIFREQ     (* (reg8 *) freqMod__SIO_REG_HIFREQ)
    #define freqMod_SIO_CFG            (* (reg8 *) freqMod__SIO_CFG)
    #define freqMod_SIO_DIFF           (* (reg8 *) freqMod__SIO_DIFF)
#endif /* (freqMod__SIO_CFG) */

/* Interrupt Registers */
#if defined(freqMod__INTSTAT)
    #define freqMod_INTSTAT            (* (reg8 *) freqMod__INTSTAT)
    #define freqMod_SNAP               (* (reg8 *) freqMod__SNAP)
    
	#define freqMod_0_INTTYPE_REG 		(* (reg8 *) freqMod__0__INTTYPE)
#endif /* (freqMod__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_freqMod_H */


/* [] END OF FILE */
