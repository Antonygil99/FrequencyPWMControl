/*******************************************************************************
* File Name: dutyMod.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_dutyMod_H) /* Pins dutyMod_H */
#define CY_PINS_dutyMod_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "dutyMod_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 dutyMod__PORT == 15 && ((dutyMod__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    dutyMod_Write(uint8 value);
void    dutyMod_SetDriveMode(uint8 mode);
uint8   dutyMod_ReadDataReg(void);
uint8   dutyMod_Read(void);
void    dutyMod_SetInterruptMode(uint16 position, uint16 mode);
uint8   dutyMod_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the dutyMod_SetDriveMode() function.
     *  @{
     */
        #define dutyMod_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define dutyMod_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define dutyMod_DM_RES_UP          PIN_DM_RES_UP
        #define dutyMod_DM_RES_DWN         PIN_DM_RES_DWN
        #define dutyMod_DM_OD_LO           PIN_DM_OD_LO
        #define dutyMod_DM_OD_HI           PIN_DM_OD_HI
        #define dutyMod_DM_STRONG          PIN_DM_STRONG
        #define dutyMod_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define dutyMod_MASK               dutyMod__MASK
#define dutyMod_SHIFT              dutyMod__SHIFT
#define dutyMod_WIDTH              1u

/* Interrupt constants */
#if defined(dutyMod__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in dutyMod_SetInterruptMode() function.
     *  @{
     */
        #define dutyMod_INTR_NONE      (uint16)(0x0000u)
        #define dutyMod_INTR_RISING    (uint16)(0x0001u)
        #define dutyMod_INTR_FALLING   (uint16)(0x0002u)
        #define dutyMod_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define dutyMod_INTR_MASK      (0x01u) 
#endif /* (dutyMod__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define dutyMod_PS                     (* (reg8 *) dutyMod__PS)
/* Data Register */
#define dutyMod_DR                     (* (reg8 *) dutyMod__DR)
/* Port Number */
#define dutyMod_PRT_NUM                (* (reg8 *) dutyMod__PRT) 
/* Connect to Analog Globals */                                                  
#define dutyMod_AG                     (* (reg8 *) dutyMod__AG)                       
/* Analog MUX bux enable */
#define dutyMod_AMUX                   (* (reg8 *) dutyMod__AMUX) 
/* Bidirectional Enable */                                                        
#define dutyMod_BIE                    (* (reg8 *) dutyMod__BIE)
/* Bit-mask for Aliased Register Access */
#define dutyMod_BIT_MASK               (* (reg8 *) dutyMod__BIT_MASK)
/* Bypass Enable */
#define dutyMod_BYP                    (* (reg8 *) dutyMod__BYP)
/* Port wide control signals */                                                   
#define dutyMod_CTL                    (* (reg8 *) dutyMod__CTL)
/* Drive Modes */
#define dutyMod_DM0                    (* (reg8 *) dutyMod__DM0) 
#define dutyMod_DM1                    (* (reg8 *) dutyMod__DM1)
#define dutyMod_DM2                    (* (reg8 *) dutyMod__DM2) 
/* Input Buffer Disable Override */
#define dutyMod_INP_DIS                (* (reg8 *) dutyMod__INP_DIS)
/* LCD Common or Segment Drive */
#define dutyMod_LCD_COM_SEG            (* (reg8 *) dutyMod__LCD_COM_SEG)
/* Enable Segment LCD */
#define dutyMod_LCD_EN                 (* (reg8 *) dutyMod__LCD_EN)
/* Slew Rate Control */
#define dutyMod_SLW                    (* (reg8 *) dutyMod__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define dutyMod_PRTDSI__CAPS_SEL       (* (reg8 *) dutyMod__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define dutyMod_PRTDSI__DBL_SYNC_IN    (* (reg8 *) dutyMod__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define dutyMod_PRTDSI__OE_SEL0        (* (reg8 *) dutyMod__PRTDSI__OE_SEL0) 
#define dutyMod_PRTDSI__OE_SEL1        (* (reg8 *) dutyMod__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define dutyMod_PRTDSI__OUT_SEL0       (* (reg8 *) dutyMod__PRTDSI__OUT_SEL0) 
#define dutyMod_PRTDSI__OUT_SEL1       (* (reg8 *) dutyMod__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define dutyMod_PRTDSI__SYNC_OUT       (* (reg8 *) dutyMod__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(dutyMod__SIO_CFG)
    #define dutyMod_SIO_HYST_EN        (* (reg8 *) dutyMod__SIO_HYST_EN)
    #define dutyMod_SIO_REG_HIFREQ     (* (reg8 *) dutyMod__SIO_REG_HIFREQ)
    #define dutyMod_SIO_CFG            (* (reg8 *) dutyMod__SIO_CFG)
    #define dutyMod_SIO_DIFF           (* (reg8 *) dutyMod__SIO_DIFF)
#endif /* (dutyMod__SIO_CFG) */

/* Interrupt Registers */
#if defined(dutyMod__INTSTAT)
    #define dutyMod_INTSTAT            (* (reg8 *) dutyMod__INTSTAT)
    #define dutyMod_SNAP               (* (reg8 *) dutyMod__SNAP)
    
	#define dutyMod_0_INTTYPE_REG 		(* (reg8 *) dutyMod__0__INTTYPE)
#endif /* (dutyMod__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_dutyMod_H */


/* [] END OF FILE */
