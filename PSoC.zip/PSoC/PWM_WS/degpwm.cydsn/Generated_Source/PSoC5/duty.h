/*******************************************************************************
* File Name: duty.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_duty_H) /* Pins duty_H */
#define CY_PINS_duty_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "duty_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 duty__PORT == 15 && ((duty__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    duty_Write(uint8 value);
void    duty_SetDriveMode(uint8 mode);
uint8   duty_ReadDataReg(void);
uint8   duty_Read(void);
void    duty_SetInterruptMode(uint16 position, uint16 mode);
uint8   duty_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the duty_SetDriveMode() function.
     *  @{
     */
        #define duty_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define duty_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define duty_DM_RES_UP          PIN_DM_RES_UP
        #define duty_DM_RES_DWN         PIN_DM_RES_DWN
        #define duty_DM_OD_LO           PIN_DM_OD_LO
        #define duty_DM_OD_HI           PIN_DM_OD_HI
        #define duty_DM_STRONG          PIN_DM_STRONG
        #define duty_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define duty_MASK               duty__MASK
#define duty_SHIFT              duty__SHIFT
#define duty_WIDTH              1u

/* Interrupt constants */
#if defined(duty__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in duty_SetInterruptMode() function.
     *  @{
     */
        #define duty_INTR_NONE      (uint16)(0x0000u)
        #define duty_INTR_RISING    (uint16)(0x0001u)
        #define duty_INTR_FALLING   (uint16)(0x0002u)
        #define duty_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define duty_INTR_MASK      (0x01u) 
#endif /* (duty__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define duty_PS                     (* (reg8 *) duty__PS)
/* Data Register */
#define duty_DR                     (* (reg8 *) duty__DR)
/* Port Number */
#define duty_PRT_NUM                (* (reg8 *) duty__PRT) 
/* Connect to Analog Globals */                                                  
#define duty_AG                     (* (reg8 *) duty__AG)                       
/* Analog MUX bux enable */
#define duty_AMUX                   (* (reg8 *) duty__AMUX) 
/* Bidirectional Enable */                                                        
#define duty_BIE                    (* (reg8 *) duty__BIE)
/* Bit-mask for Aliased Register Access */
#define duty_BIT_MASK               (* (reg8 *) duty__BIT_MASK)
/* Bypass Enable */
#define duty_BYP                    (* (reg8 *) duty__BYP)
/* Port wide control signals */                                                   
#define duty_CTL                    (* (reg8 *) duty__CTL)
/* Drive Modes */
#define duty_DM0                    (* (reg8 *) duty__DM0) 
#define duty_DM1                    (* (reg8 *) duty__DM1)
#define duty_DM2                    (* (reg8 *) duty__DM2) 
/* Input Buffer Disable Override */
#define duty_INP_DIS                (* (reg8 *) duty__INP_DIS)
/* LCD Common or Segment Drive */
#define duty_LCD_COM_SEG            (* (reg8 *) duty__LCD_COM_SEG)
/* Enable Segment LCD */
#define duty_LCD_EN                 (* (reg8 *) duty__LCD_EN)
/* Slew Rate Control */
#define duty_SLW                    (* (reg8 *) duty__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define duty_PRTDSI__CAPS_SEL       (* (reg8 *) duty__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define duty_PRTDSI__DBL_SYNC_IN    (* (reg8 *) duty__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define duty_PRTDSI__OE_SEL0        (* (reg8 *) duty__PRTDSI__OE_SEL0) 
#define duty_PRTDSI__OE_SEL1        (* (reg8 *) duty__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define duty_PRTDSI__OUT_SEL0       (* (reg8 *) duty__PRTDSI__OUT_SEL0) 
#define duty_PRTDSI__OUT_SEL1       (* (reg8 *) duty__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define duty_PRTDSI__SYNC_OUT       (* (reg8 *) duty__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(duty__SIO_CFG)
    #define duty_SIO_HYST_EN        (* (reg8 *) duty__SIO_HYST_EN)
    #define duty_SIO_REG_HIFREQ     (* (reg8 *) duty__SIO_REG_HIFREQ)
    #define duty_SIO_CFG            (* (reg8 *) duty__SIO_CFG)
    #define duty_SIO_DIFF           (* (reg8 *) duty__SIO_DIFF)
#endif /* (duty__SIO_CFG) */

/* Interrupt Registers */
#if defined(duty__INTSTAT)
    #define duty_INTSTAT            (* (reg8 *) duty__INTSTAT)
    #define duty_SNAP               (* (reg8 *) duty__SNAP)
    
	#define duty_0_INTTYPE_REG 		(* (reg8 *) duty__0__INTTYPE)
#endif /* (duty__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_duty_H */


/* [] END OF FILE */
